#!/data/data/com.termux/files/usr/bin/bash

declare -a NOTIFICATION_MESSAGE=("Wish you a good day!" "" "-a Welcome!")
declare -a PRELOAD_PROPERTIES=("$HOME/.local/media/windows-11-startup-sound-effect.mp3" 5 4)