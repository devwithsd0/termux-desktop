#!/data/data/com.termux/files/usr/bin/sh

export SAVED_DIRECTORY="$HOME/Screenshots"
export WAITING_TIMER="${1:-3}"

if [ ! -e "$SAVED_DIRECTORY" ]; then
	mkdir -p "$SAVED_DIRECTORY"
fi

if [ -z "$(command -v scrot)" ]; then
	notify-send "Required executable not found." -u critical -a "Failed!" -w
	exit 1
else
	notify-send "Version: $(scrot -v | sed 's/scrot version//' | tr -d ' ')" "To take a clean screenshot, get ready your screen by aligning stuffs for showing off.\n\nDestination: $SAVED_DIRECTORY\nTimer: $WAITING_TIMER second(s).\n\nIf everything is done, close this message. After that, a countdown starts. Then a state will be captured as is." -u low -t 480000 -a "Say... Cheese!" -w
	cd "$SAVED_DIRECTORY"
	scrot -c -d "$WAITING_TIMER" -D "$DISPLAY"
	notify-send "Captcha! Got your picture... Check it out." -u low -a "Congrats!" -w
fi