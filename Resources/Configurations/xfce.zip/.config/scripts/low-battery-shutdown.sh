#!/data/data/com.termux/files/usr/bin/bash

declare -i WAIT_TIMER="${1:-60}"

if [ -n "$TERMUX_API_VERSION" ] && termux-api-start; then
	notify-send "You are A MONSTER!" "Please! Just go now and connect me with the charger. Battery is running out. I will be turned off automatically in about some seconds." -u critical -i face-angry -w
	termux-api-stop
	sleep "$WAIT_TIMER"
	xsmgmt stop
else
	echo "Error occurred during reading device properties."
	exit 1
fi