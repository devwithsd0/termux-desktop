#!/data/data/com.termux/files/usr/bin/python

##############################################
## All your ongoing work results may be     ##
## lost just because of your careless use.  ##
## Actually, one can refresh a currently    ##
## live session browsing by the real owner. ##
##############################################


from os import remove, system
from os.path import exists
from subprocess import check_output, Popen
from sys import argv, exit as quit
from tkinter.messagebox import askyesno, showinfo

def execute(command):
	return check_output(command, shell = True, text = True)

class Cell:
	saved_pipe = execute("echo -n $HOME/.cache/_vsr.out")
	watched_processes = execute(f"pgrep -f {argv[0]}")

if system(f"test -f {Cell.saved_pipe}"):
	if exists(Cell.saved_pipe):
		system(f"rm -r {Cell.saved_pipe}")
	with open(Cell.saved_pipe, "w") as file:
		file.write(Cell.watched_processes)

with open(Cell.saved_pipe) as file:
	if file.read() == Cell.watched_processes:
		if askyesno("Are you sure?", "Save all of your pending works because after next, any unsaved data will be lost forever. Or if you have made changes in major settings, it will refresh to help on taking action.\n\n\nPreferred: After updating environment variables, 'Fonts' or 'Icon Packs' etc."):
			system("clear")
			system("echo -n 'Waiting before elevation... '")
			Popen(f"setsid python {argv[0]} & disown", executable = execute("command -v bash").removesuffix("\n"), shell = True)
			while exists(Cell.saved_pipe):
				pass
			quit()
		else:
			remove(Cell.saved_pipe)
			showinfo("", "Operation cancelled.")
			system("clear")
			quit(True)
	else:
		remove(Cell.saved_pipe)
		system("xsmgmt stop")
		while True:
			if system("pidof Xvnc"):
				system("xsmgmt start 0")
				system("clear")
				break
		quit()