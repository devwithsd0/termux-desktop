#!/data/data/com.termux/files/usr/bin/bash

declare -a NOTIFICATION_MESSAGE=("Welcome!" "Wish you a good day!" "-i face-wink")
declare -a PRELOAD_PROPERTIES=("$HOME/.local/media/soft-startup-sound-269291.mp3" 7 6)